# hopper-server
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/47d2d67f2a0448578e2bc2aeb6568037)](https://app.codacy.com/gh/hopperteam/hopper-server?utm_source=github.com&utm_medium=referral&utm_content=hopperteam/hopper-server&utm_campaign=Badge_Grade_Dashboard)

[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=hopperteam_hopper-server&metric=alert_status)](https://sonarcloud.io/dashboard?id=hopperteam_hopper-server)
