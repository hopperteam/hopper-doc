
export default interface ISanitizer {
    sanitize(json: any, extended: boolean) : void;
}
