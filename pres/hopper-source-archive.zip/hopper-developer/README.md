# Hopper developer manual
Welcome to Hopper's developer manual!

To get introductions into Hopper's API head to the [API documentation](api.md). To get the documentation for the libraries, go to the [library documentation](documentation.md).
