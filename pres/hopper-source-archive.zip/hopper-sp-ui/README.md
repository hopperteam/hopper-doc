# Hopper SP

## Example .env:

```
PORT=4000
MONGOURI=mongodb://127.0.0.1:27017/local
PASSPHRASE=0adf5AD11A23adfAD524f8DFA9495sa7AD3DF6543
BASEURL=http://localhost
SPREQUESTURL=https://api-dev.hoppercloud.net/v1/app
NOTIFICATIONURL=https://api-dev.hoppercloud.net/v1/notification
CALLBACKURL=http://localhost:4000/subscriber
REDIRECTURL=https://dev.hoppercloud.net/subscribe
JWTCERTPATH=../cert
PERMISSIONNAMESPACE=HopperDev
AUTHREDIRECTURL=https://account.hoppercloud.net
```